
import React, { useRef, useEffect, useState } from 'react';
import { Eraser, Trash2, Download, ChevronLeft, Minus, Plus } from 'lucide-react';

interface ColoringCanvasProps {
  imageSrc: string;
  onBack: () => void;
}

const COLORS = [
  '#FF0000', '#FF7F00', '#FFFF00', '#00FF00', '#0000FF', '#4B0082', 
  '#8B00FF', '#FF69B4', '#8B4513', '#000000', '#FFFFFF', '#00FFFF'
];

const ColoringCanvas: React.FC<ColoringCanvasProps> = ({ imageSrc, onBack }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const contextRef = useRef<CanvasRenderingContext2D | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [color, setColor] = useState('#FF0000');
  const [brushSize, setBrushSize] = useState(10);
  const [isEraser, setIsEraser] = useState(false);
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      const containerWidth = container.clientWidth;
      const aspectRatio = img.height / img.width;
      
      // Set canvas display size
      canvas.style.width = `${containerWidth}px`;
      canvas.style.height = `${containerWidth * aspectRatio}px`;
      
      // Set actual internal resolution to match image size for quality
      canvas.width = img.width;
      canvas.height = img.height;

      const context = canvas.getContext('2d', { willReadFrequently: true });
      if (context) {
        context.lineCap = 'round';
        context.lineJoin = 'round';
        
        // Initial draw: White background + Line Art
        context.fillStyle = 'white';
        context.fillRect(0, 0, canvas.width, canvas.height);
        context.drawImage(img, 0, 0, canvas.width, canvas.height);
        
        contextRef.current = context;
        setIsReady(true);
      }
    };
    img.src = imageSrc;
  }, [imageSrc]);

  const getCoordinates = (e: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };

    const rect = canvas.getBoundingClientRect();
    let clientX, clientY;

    if ('touches' in e) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    // Scale coordinates back to internal canvas resolution
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY
    };
  };

  const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isReady) return;
    const { x, y } = getCoordinates(e);
    contextRef.current?.beginPath();
    contextRef.current?.moveTo(x, y);
    setIsDrawing(true);
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing || !isReady) return;
    const { x, y } = getCoordinates(e);
    
    const ctx = contextRef.current;
    if (ctx) {
      ctx.strokeStyle = isEraser ? 'white' : color;
      ctx.lineWidth = brushSize * (canvasRef.current!.width / 400); // Scale brush to resolution
      
      // Multiplikations-Effekt: Malt hinter den schwarzen Linien
      ctx.globalCompositeOperation = isEraser ? 'source-over' : 'multiply';
      
      ctx.lineTo(x, y);
      ctx.stroke();
    }
  };

  const stopDrawing = () => {
    contextRef.current?.closePath();
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    const ctx = contextRef.current;
    const canvas = canvasRef.current;
    if (ctx && canvas) {
      ctx.globalCompositeOperation = 'source-over';
      ctx.fillStyle = 'white';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      const img = new Image();
      img.onload = () => ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      img.src = imageSrc;
    }
  };

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = 'alice-kunstwerk.png';
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  return (
    <div className="flex flex-col gap-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between px-2">
        <button onClick={onBack} className="p-2 bg-gray-900 rounded-full text-gray-400 active:bg-gray-800 transition-colors">
          <ChevronLeft size={24} />
        </button>
        <div className="flex gap-4">
          <button onClick={clearCanvas} className="p-2 bg-gray-900 rounded-full text-red-500 active:bg-red-900/20">
            <Trash2 size={24} />
          </button>
          <button onClick={handleDownload} className="flex items-center gap-2 bg-green-600 px-4 py-2 rounded-full font-bold shadow-lg shadow-green-900/20 active:scale-95 transition-all">
            <Download size={20} /> Speichern
          </button>
        </div>
      </div>

      <div ref={containerRef} className="relative w-full rounded-3xl overflow-hidden shadow-2xl border-2 border-white/10 touch-none bg-white">
        {!isReady && (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-900">
            <div className="animate-spin rounded-full h-12 w-12 border-4 border-white border-t-transparent"></div>
          </div>
        )}
        <canvas
          ref={canvasRef}
          onMouseDown={startDrawing}
          onMouseMove={draw}
          onMouseUp={stopDrawing}
          onMouseLeave={stopDrawing}
          onTouchStart={startDrawing}
          onTouchMove={draw}
          onTouchEnd={stopDrawing}
          className="block mx-auto"
        />
      </div>

      <div className="space-y-6 pb-4">
        {/* Brush size slider UI */}
        <div className="flex items-center gap-4 bg-gray-900 p-4 rounded-2xl">
          <button onClick={() => setBrushSize(Math.max(2, brushSize - 5))} className="p-2 bg-gray-800 rounded-lg text-white active:scale-90">
            <Minus size={20} />
          </button>
          <div className="flex-1 px-2">
             <div className="h-1.5 w-full bg-gray-800 rounded-full overflow-hidden">
                <div className="h-full bg-blue-500" style={{ width: `${(brushSize/50)*100}%` }}></div>
             </div>
          </div>
          <button onClick={() => setBrushSize(Math.min(50, brushSize + 5))} className="p-2 bg-gray-800 rounded-lg text-white active:scale-90">
            <Plus size={20} />
          </button>
          <div className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center bg-black">
            <div 
              className="rounded-full transition-all duration-200" 
              style={{ 
                width: Math.max(2, brushSize/1.5), 
                height: Math.max(2, brushSize/1.5), 
                backgroundColor: isEraser ? 'white' : color 
              }}
            ></div>
          </div>
        </div>

        {/* Color Palette */}
        <div className="grid grid-cols-7 gap-3 justify-items-center">
          <button
            onClick={() => setIsEraser(true)}
            className={`w-12 h-12 rounded-2xl flex items-center justify-center border-2 transition-all active:scale-90 ${isEraser ? 'border-blue-500 bg-blue-500/20 scale-110' : 'border-transparent bg-gray-800 text-gray-400'}`}
          >
            <Eraser size={24} />
          </button>
          {COLORS.map((c) => (
            <button
              key={c}
              onClick={() => {
                setColor(c);
                setIsEraser(false);
              }}
              className={`w-12 h-12 rounded-2xl border-4 transition-all active:scale-90 ${!isEraser && color === c ? 'border-white scale-110 shadow-lg' : 'border-transparent'}`}
              style={{ backgroundColor: c }}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default ColoringCanvas;
