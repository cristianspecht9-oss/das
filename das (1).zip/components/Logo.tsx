
import React from 'react';

const Logo: React.FC<{ size?: 'sm' | 'md' | 'lg' }> = ({ size = 'md' }) => {
  const sizeClasses = {
    sm: 'w-12 h-12 text-2xl',
    md: 'w-24 h-24 text-6xl',
    lg: 'w-36 h-36 text-8xl'
  };

  return (
    <div className={`${sizeClasses[size]} bg-black border-[3px] border-white/10 rounded-[2rem] flex items-center justify-center shadow-[0_20px_50px_rgba(0,0,0,0.5)] overflow-hidden relative group`}>
      {/* Glossy overlay */}
      <div className="absolute inset-0 bg-gradient-to-tr from-white/5 to-transparent opacity-50"></div>
      <span className="font-extrabold text-white tracking-tighter z-10 select-none">
        A
      </span>
      {/* Accent corner */}
      <div className="absolute top-0 right-0 w-8 h-8 bg-white/5 blur-xl"></div>
    </div>
  );
};

export default Logo;
