
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY || '';

export const transformToColoringPage = async (base64Image: string, style: string): Promise<string> => {
  if (!API_KEY) {
    throw new Error("API Key ist nicht konfiguriert.");
  }

  const ai = new GoogleGenAI({ apiKey: API_KEY });
  
  // Prepare image part
  const imagePart = {
    inlineData: {
      mimeType: 'image/jpeg',
      data: base64Image.split(',')[1],
    },
  };

  const prompt = `Transform this photo into a high-quality black and white coloring page for children. 
  Style: ${style}. 
  Requirements:
  - NO color, strictly black lines on a white background.
  - Clear, clean outlines that are easy to color.
  - Remove all shading and gradients; use only line art.
  - The final image must look like a page from a coloring book.
  - Maintain the recognizable features of the original subject.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: { parts: [imagePart, { text: prompt }] },
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    
    throw new Error("Keine Linien generiert.");
  } catch (error) {
    console.error("Gemini Error:", error);
    throw new Error("Ups! Der Zauberstift ist abgebrochen. Versuche es noch einmal.");
  }
};
